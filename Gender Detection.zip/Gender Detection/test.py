def main():
    print("Script is running...")
    print("4.10.0")

if __name__ == "__main__":
    main()
